/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_442()
{
    return 2445773128U;
}

void setval_337(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_115(unsigned x)
{
    return x + 3251079496U;
}

unsigned addval_168(unsigned x)
{
    return x + 2421723661U;
}

void setval_354(unsigned *p)
{
    *p = 2421742500U;
}

unsigned addval_433(unsigned x)
{
    return x + 2420668808U;
}

unsigned addval_138(unsigned x)
{
    return x + 2425387107U;
}

unsigned addval_217(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_415()
{
    return 3674262153U;
}

void setval_313(unsigned *p)
{
    *p = 3682912937U;
}

unsigned getval_183()
{
    return 3372799641U;
}

unsigned getval_497()
{
    return 3221275017U;
}

unsigned addval_422(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_270()
{
    return 3286272344U;
}

void setval_254(unsigned *p)
{
    *p = 3223374537U;
}

void setval_204(unsigned *p)
{
    *p = 3677932233U;
}

unsigned getval_350()
{
    return 3375421065U;
}

unsigned addval_268(unsigned x)
{
    return x + 3526934921U;
}

unsigned getval_190()
{
    return 3374896777U;
}

unsigned getval_167()
{
    return 2497743176U;
}

unsigned addval_364(unsigned x)
{
    return x + 3525367433U;
}

void setval_263(unsigned *p)
{
    *p = 3767093288U;
}

void setval_360(unsigned *p)
{
    *p = 3281043721U;
}

unsigned addval_396(unsigned x)
{
    return x + 3281049257U;
}

unsigned addval_287(unsigned x)
{
    return x + 2428602776U;
}

unsigned getval_154()
{
    return 3269495112U;
}

unsigned addval_319(unsigned x)
{
    return x + 2425405837U;
}

void setval_324(unsigned *p)
{
    *p = 3286273352U;
}

unsigned addval_475(unsigned x)
{
    return x + 3674784009U;
}

unsigned addval_245(unsigned x)
{
    return x + 3389642740U;
}

unsigned addval_436(unsigned x)
{
    return x + 3229928073U;
}

unsigned addval_494(unsigned x)
{
    return x + 2425405832U;
}

void setval_185(unsigned *p)
{
    *p = 3531921033U;
}

unsigned addval_306(unsigned x)
{
    return x + 3767093361U;
}

unsigned getval_123()
{
    return 2497743176U;
}

unsigned getval_346()
{
    return 3200505497U;
}

void setval_359(unsigned *p)
{
    *p = 2425408137U;
}

void setval_417(unsigned *p)
{
    *p = 2446756251U;
}

unsigned addval_232(unsigned x)
{
    return x + 3223896457U;
}

unsigned getval_187()
{
    return 3229928065U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
